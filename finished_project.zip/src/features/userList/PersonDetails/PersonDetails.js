// moment was used in order to not reinvent the age calculation
import moment from "moment";

export default function PersonDetails(props) {
    const { details, isActive } = props;

    return isActive ?
        <div>
            <p>{details.about}</p>
            <div>
                {details.showDob ? <span>Age: {moment().diff(details.dob, 'years')}</span> : null}
            </div>
            <div>
                {details.showGender ? <span>Gender: {details.gender}</span> : null}
            </div>
        </div>
        : null
}
