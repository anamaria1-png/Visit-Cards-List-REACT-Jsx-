import './PersonCard.css';
import PersonDetails from '../PersonDetails/PersonDetails';

export default function PersonCard(props) {
    // expand the props object in order to not have to write
    // props.KEY every time I need a property
    const { person, handler, isActive } = props;

    //wrapper for the handler passed in the props
    //this is done in order to make sure the handler gets the correct
    //person
    const onClickHandler = () => {
        handler(person);
    }

    return <div className={isActive ? 'cardActive' : 'card'} onClick={onClickHandler}>
        <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
                <span className='alignToStart'>Name: {person.firstName} {person.lastName}</span>
                <span className='alignToStart'>{person.email}</span>
            </div>
            <div>
                <img src={person.profilePicture}></img>
            </div>
        </div>
        <PersonDetails details={person.info} isActive={isActive}></PersonDetails>
        </div>
}