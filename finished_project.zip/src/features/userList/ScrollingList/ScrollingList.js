import React, { useState, useEffect } from 'react';
import PersonCard from '../PersonCard/PersonCard';

export default function ScrollingList(props) {
    const [activeCard, setActiveCard] = useState(0);

    //sets the state and resets it on the second click on the same card
    const onCardClickHandler = (person) => {
        if (person.id === activeCard)
            setActiveCard(0);
        else
            setActiveCard(person.id);
    }

    return <div>
        {props.data.map((person) =>
            <div>
                <PersonCard
                    person={person} 
                    handler={onCardClickHandler}
                    isActive={person.id === activeCard}></PersonCard>
            </div>
        )}
    </div>
}