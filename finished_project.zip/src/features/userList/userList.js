import data from '../../mockData';
import ScrollingList from './ScrollingList/ScrollingList';
import useProtectedRoute from "../hooks/protectedRoute";

export default function UserList() {

    useProtectedRoute();
    
    return  <ScrollingList data={data} />
}