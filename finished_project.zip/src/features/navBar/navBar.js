import { Link } from "react-router-dom";
export default function NavBar() {
    return (
        <nav style={{ textAlign: "center", marginTop: "20px" }}>
            <Link to="/" style={{ padding: "10px" }}> Home</Link>
            <Link to="/counter" style={{ padding: "10px" }}> Counter</Link>
            <Link to="/userInfo" style={{ padding: "10px" }}> UserInfo</Link>
        </nav>
    )
}