import { useNavigate } from "react-router-dom";
import { useSelector } from 'react-redux';
import { useEffect } from 'react';

export default function useProtectedRoute() {
    const isLoggedIn = useSelector(state => state.authentication.isLoggedIn)
    const navigate = useNavigate();

    useEffect(() => {
        if (!isLoggedIn) {
            navigate("/", { replace: true});
        }
    }, []);
}